import React, { useState } from 'react';
import { Button, Container, Typography, Box, Tabs, Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';
import { styled } from '@mui/system';
import SiteMap from '../components/SiteMap';
import 'leaflet/dist/leaflet.css';

const Input = styled('input')({
  display: 'none',
});

const ExcelAnalyzer = () => {
  const [file, setFile] = useState(null);
  const [analysisResult, setAnalysisResult] = useState(null);
  const [activeTab, setActiveTab] = useState(0);

  const handleFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const handleSubmit = async () => {
    if (!file) {
      alert('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/analyze-excel/', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        setAnalysisResult(result);
      } else {
        alert('Error analyzing file. Please try again.');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again.');
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const renderFilteredCalls = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Number</TableCell>
            <TableCell>Number of Calls</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analysisResult.filtered_calls.map((call, index) => (
            <TableRow key={index}>
              <TableCell>{call.Number}</TableCell>
              <TableCell>{call.Number_of_Calls}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderAggregatedCallerNumbers = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Caller Number</TableCell>
            <TableCell>Number of Calls</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analysisResult.aggregated_caller_numbers.map((item, index) => (
            <TableRow key={index}>
              <TableCell>{item.CALLER_NUMBER}</TableCell>
              <TableCell>{item.Number_of_Calls}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderImeiUsage = () => (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>IMEI</TableCell>
            <TableCell>Usage Period</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {analysisResult.imei_usage.map((item, index) => (
            <TableRow key={index}>
              <TableCell>{item.CHARGED_MOBILE_USER_IMEI}</TableCell>
              <TableCell>{item.Usage_Period}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );

  const renderMostVisitedSites = () => (
    <Box>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Site ID</TableCell>
              <TableCell>Site Name</TableCell>
              <TableCell>Number of Visits</TableCell>
              <TableCell>Latitude</TableCell>
              <TableCell>Longitude</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {analysisResult.most_visited_sites.map((site, index) => (
              <TableRow key={index}>
                <TableCell>{site.SITE_ID}</TableCell>
                <TableCell>{site.SITE_NAME}</TableCell>
                <TableCell>{site.Number_of_Visits}</TableCell>
                <TableCell>{site.LAT}</TableCell>
                <TableCell>{site.LON}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );

  const renderMap = () => (
    <Box mt={2} style={{ height: '600px' }}>
      <SiteMap sites={analysisResult.most_visited_sites} />
    </Box>
  );

  return (
    <Container maxWidth="md">
      <Typography variant="h4" gutterBottom>
        Excel Analyzer Tool
      </Typography>
      <Box mb={2}>
        <Input
          accept=".xlsx,.xls"
          id="contained-button-file"
          type="file"
          onChange={handleFileChange}
        />
        <label htmlFor="contained-button-file">
          <Button variant="contained" component="span">
            Upload
          </Button>
        </label>
        {file && <Typography>{file.name}</Typography>}
      </Box>
      <Button variant="contained" color="primary" onClick={handleSubmit}>
        Analyze
      </Button>
      {analysisResult && (
        <Box mt={4}>
          <Typography variant="h5">Analysis Results</Typography>
          <Tabs value={activeTab} onChange={handleTabChange}>
            <Tab label="Filtered Calls" />
            <Tab label="Aggregated Caller Numbers" />
            <Tab label="IMEI Usage" />
            <Tab label="Most Visited Sites" />
            <Tab label="Map" />
          </Tabs>
          <Box mt={2}>
            {activeTab === 0 && renderFilteredCalls()}
            {activeTab === 1 && renderAggregatedCallerNumbers()}
            {activeTab === 2 && renderImeiUsage()}
            {activeTab === 3 && renderMostVisitedSites()}
            {activeTab === 4 && renderMap()}
          </Box>
        </Box>
      )}
    </Container>
  );
};

export default ExcelAnalyzer;
