import React, { useState } from 'react';
import { Button, Container, Typography, Tab, Tabs, Box, CircularProgress, Alert } from '@mui/material';
import axios from 'axios';
import DataTable from '../components/DataTable';
import SiteMap from '../components/SiteMap';
import strings from '../localization/strings';

function ExcelAnalyzerZ() {
  const [mainFile, setMainFile] = useState(null);
  const [imeiFile, setImeiFile] = useState(null);
  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleMainFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      setMainFile(file);
      setError(null);
    } else {
      setError("Please upload a valid Excel file (.xlsx) for the main sheet.");
    }
  };

  const handleImeiFileChange = (event) => {
    const file = event.target.files[0];
    if (file && file.type === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      setImeiFile(file);
      setError(null);
    } else {
      setError("Please upload a valid Excel file (.xlsx) for the IMEI sheet.");
    }
  };

  const handleSubmit = async () => {
    if (!mainFile || !imeiFile) {
      setError("Please upload both main and IMEI files before analyzing.");
      return;
    }

    setLoading(true);
    setError(null);

    const formData = new FormData();
    formData.append('main_file', mainFile);
    formData.append('imei_file', imeiFile);

    try {
      const response = await axios.post('http://localhost:8000/api/analyze-excel-z/', formData);
      setResults(response.data);
    } catch (error) {
      console.error('Error analyzing Excel files:', error);
      setError(error.response?.data?.error || "An error occurred while analyzing the files. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  return (
    <Container>
      <Typography variant="h4" component="h1" gutterBottom>
        {strings.excelAnalyzerZTitle}
      </Typography>
      <Box mb={2}>
        <input
          accept=".xlsx"
          id="main-file-input"
          type="file"
          onChange={handleMainFileChange}
          style={{ display: 'none' }}
        />
        <label htmlFor="main-file-input">
          <Button variant="contained" component="span">
            {strings.uploadMainFile}
          </Button>
        </label>
        {mainFile && <Typography>{mainFile.name}</Typography>}
      </Box>
      <Box mb={2}>
        <input
          accept=".xlsx"
          id="imei-file-input"
          type="file"
          onChange={handleImeiFileChange}
          style={{ display: 'none' }}
        />
        <label htmlFor="imei-file-input">
          <Button variant="contained" component="span">
            {strings.uploadImeiFile}
          </Button>
        </label>
        {imeiFile && <Typography>{imeiFile.name}</Typography>}
      </Box>
      <Button
        variant="contained"
        color="primary"
        onClick={handleSubmit}
        disabled={loading || !mainFile || !imeiFile}
      >
        {loading ? <CircularProgress size={24} /> : strings.analyze}
      </Button>
      {error && (
        <Alert severity="error" sx={{ mt: 2 }}>
          {error}
        </Alert>
      )}
      {results && (
        <Box sx={{ width: '100%', mt: 3 }}>
          <Tabs value={activeTab} onChange={handleTabChange} aria-label="analysis results tabs">
            <Tab label={strings.filteredCalls} />
            <Tab label={strings.imeiUsage} />
            <Tab label={strings.mostVisitedSites} />
            <Tab label={strings.siteMap} />
          </Tabs>
          <Box sx={{ p: 3 }}>
            {activeTab === 0 && <DataTable data={results.filtered_calls} />}
            {activeTab === 1 && <DataTable data={results.imei_usage} />}
            {activeTab === 2 && <DataTable data={results.most_visited_sites} />}
            {activeTab === 3 && <SiteMap sites={results.most_visited_sites || []} />}
          </Box>
        </Box>
      )}
    </Container>
  );
}

export default ExcelAnalyzerZ;