const strings = {
  // App General
  appTitle: "تطبيق أدوات متعددة",
  welcomeMessage: "مرحبًا بكم في تطبيق أدوات متعددة",
  description: "يوفر هذا التطبيق أدوات متعددة عبر الإنترنت لمساعدتك في مهام مختلفة. استخدم الشريط الجانبي للتنقل بين الأدوات المختلفة.",
  login: "تسجيل الدخول",
  analyze: "تحليل",
  noDataAvailable: "لا توجد بيانات متاحة",

  // Excel Analysis Common
  filteredCalls: "المكالمات المفلترة",
  aggregatedCallerNumbers: "أرقام المتصلين المجمعة",
  imeiUsage: "استخدام IMEI",
  mostVisitedSites: "أكثر المواقع زيارة",
  analysisResult: "نتيجة التحليل:",

  // Site Map
  siteMap: "خريطة المواقع",
  noSiteDataAvailable: "لا توجد بيانات موقع متاحة",
  noValidCoordinates: "لا توجد إحداثيات صالحة للعرض على الخريطة",
  siteId: "معرف الموقع",
  numberOfVisits: "عدد الزيارات",
  latitude: "خط العرض",
  longitude: "خط الطول",
  sortAscending: "ترتيب تصاعدي",
  sortDescending: "ترتيب تنازلي",
  sitesAtLocation: "المواقع في هذا الموقع",
  totalVisits: "إجمالي الزيارات",
  fullScreenMapButton: "خريطة ملء الشاشة",
  exitFullScreenButton: "الخروج من وضع ملء الشاشة",

  // User Authentication
  username: "اسم المستخدم",
  password: "كلمة المرور",

  // Number Lookup
  numberLookup: "البحث عن الرقم",
  enterNumber: "أدخل الرقم",
  lookup: "بحث",
  lookupResult: "نتيجة البحث",

  // Excel Analyzer Template Selection
  excelAnalyzerTitle: "تحليل ملفات إكسل",
  uploadSiteInfoTitle: "رفع معلومات المواقع",
  uploadSiteInfoButton: "رفع معلومات المواقع",
  templateSelectLabel: "اختر نوع القالب",
  originalTemplate: "القالب الأصلي",
  newTemplate: "القالب الجديد",

  // File Upload
  mainFileLabel: "الملف الرئيسي",
  imeiFileLabel: "ملف IMEI",
  analyzeButton: "تحليل",
  selectSiteInfoFile: "الرجاء اختيار ملف معلومات المواقع أولاً",
  siteInfoUploadError: "خطأ في رفع معلومات المواقع. الرجاء المحاولة مرة أخرى",
  uploadFile: "رفع الملف",
  fileUploaded: "تم رفع الملف بنجاح",
  uploadError: "خطأ في رفع الملف",

  // Excel Analyzer Z Tool
  excelAnalyzerZTitle: "تحليل ملفات إكسل Z",
  uploadMainFile: "رفع الملف الرئيسي",
  uploadImeiFile: "رفع ملف IMEI",
  processFiles: "تحليل الملفات",
  bothFilesRequired: "يجب رفع الملفين",
  processingFiles: "جاري تحليل الملفات...",
  analysisComplete: "تم اكتمال التحليل",
  analysisError: "حدث خطأ أثناء التحليل",

  // Site Information
  siteName: "اسم الموقع",
  siteLocation: "موقع المحطة",
  siteVisits: "عدد الزيارات للموقع",
  siteDetails: "تفاصيل الموقع",
  siteCoordinates: "إحداثيات الموقع",
  
  // Error Messages
  errorNoData: "لا توجد بيانات",
  errorInvalidFile: "ملف غير صالح",
  errorProcessing: "خطأ في معالجة البيانات",
  errorUpload: "خطأ في رفع الملف",
  errorInvalidCoordinates: "إحداثيات غير صالحة",
  
  // Success Messages
  successUpload: "تم رفع الملف بنجاح",
  successAnalysis: "تم تحليل البيانات بنجاح",
  successSiteInfo: "تم حفظ معلومات المواقع بنجاح"
};

export default strings;