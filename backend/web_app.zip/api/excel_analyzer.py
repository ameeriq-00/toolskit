import pandas as pd
import numpy as np
from .models import SiteInformation

def process_excel_files(main_file, imei_file):
    main_df = pd.read_excel(main_file, skiprows=5)
    imei_df = pd.read_excel(imei_file, skiprows=8)
    
    # Get sheet owner number from most frequent number in calls
    sheet_owner_number = find_sheet_owner_number(main_df)
    print(f"Detected sheet owner number: {sheet_owner_number}")  # Debug print

    return {
        "filtered_calls": filter_and_aggregate_calls_new(main_df),
        "aggregated_caller_numbers": aggregate_by_caller_number_new(main_df),
        "imei_usage": aggregate_imei_usage_new(imei_df, sheet_owner_number),
        "most_visited_sites": summarize_most_visited_sites_new(main_df, sheet_owner_number)
    }

def find_sheet_owner_number(df):
    # Combine Calling and Called Numbers into a single series
    all_numbers = pd.concat([
        df['Calling Number'].astype(str),
        df['Called Number'].astype(str)
    ])
    
    # Count occurrences of each number and find the most frequent
    number_counts = all_numbers.value_counts()
    
    if not number_counts.empty:
        most_frequent_number = number_counts.index[0]
        count = number_counts.iloc[0]
        print(f"Most frequent number {most_frequent_number} appears {count} times")
        return most_frequent_number
    
    return None

def filter_and_aggregate_calls_new(df):
    df['Calling Number'] = df['Calling Number'].astype(str)
    df['Called Number'] = df['Called Number'].astype(str)
    filtered_df = df[(df['Calling Number'].str.startswith('7')) | (df['Called Number'].str.startswith('7'))]
    call_counts = filtered_df['Calling Number'].value_counts().add(filtered_df['Called Number'].value_counts(), fill_value=0)
    return call_counts.reset_index().rename(columns={'index': 'Number', 0: 'Number_of_Calls'}).to_dict('records')

def aggregate_by_caller_number_new(df):
    def is_valid_number(number):
        return isinstance(number, str) and not number.startswith('964') and not number.startswith('7')
    
    valid_numbers = df[(df['Calling Number'].apply(is_valid_number)) | (df['Called Number'].apply(is_valid_number))]
    aggregated = valid_numbers['Calling Number'].value_counts().reset_index()
    aggregated.columns = ['Number', 'Number_of_Calls']
    return aggregated.sort_values('Number_of_Calls', ascending=False).to_dict('records')

def aggregate_imei_usage_new(df, sheet_owner_number):
    if not sheet_owner_number:
        print("Warning: Sheet owner number is None. Cannot aggregate IMEI usage.")
        return []

    print(f"Aggregating IMEI usage for sheet owner: {sheet_owner_number}")  # Debug print
    
    # Convert the owner number and DataFrame numbers to string for comparison
    df['Calling Number'] = df['Calling Number'].astype(str)
    df['Called Number'] = df['Called Number'].astype(str)
    sheet_owner_number = str(sheet_owner_number)
    
    owner_imeis = df[
        ((df['Calling Number'] == sheet_owner_number) & (df['Calling IMEI'].notna())) |
        ((df['Called Number'] == sheet_owner_number) & (df['Called IMEI'].notna()))
    ]['Calling IMEI'].fillna(df['Called IMEI'])

    if owner_imeis.empty:
        print("Warning: No matching IMEI data found for sheet owner")
        return []

    imei_usage = owner_imeis.value_counts().reset_index()
    imei_usage.columns = ['IMEI', 'Usage_Count']
    
    # Calculate first and last use dates for the sheet owner's calls only
    owner_calls = df[
        (df['Calling Number'] == sheet_owner_number) |
        (df['Called Number'] == sheet_owner_number)
    ]
    
    imei_usage['First_Use'] = pd.NaT
    imei_usage['Last_Use'] = pd.NaT
    
    for idx, row in imei_usage.iterrows():
        imei = row['IMEI']
        imei_calls = owner_calls[
            (owner_calls['Calling IMEI'] == imei) |
            (owner_calls['Called IMEI'] == imei)
        ]
        if not imei_calls.empty:
            imei_usage.at[idx, 'First_Use'] = imei_calls['Date'].min()
            imei_usage.at[idx, 'Last_Use'] = imei_calls['Date'].max()

    imei_usage['Usage_Period'] = imei_usage.apply(
        lambda row: f"{row['First_Use']} to {row['Last_Use']}" if pd.notna(row['First_Use']) else "Unknown",
        axis=1
    )

    return imei_usage[['IMEI', 'Usage_Count', 'Usage_Period']].to_dict('records')

def normalize_call_type(value):
    """Normalize CALL_TYPE values to handle different formats"""
    if pd.isna(value):
        return None
    
    value = str(value).strip()
    # Add leading zeros if needed
    if value == '1':
        return '001'
    elif value == '2':
        return '002'
    return value

def summarize_most_visited_sites_new(df, sheet_owner_number):
    if not sheet_owner_number:
        print("Warning: Sheet owner number is None. Cannot summarize most visited sites.")
        return []

    # Convert the owner number and DataFrame numbers to string for comparison
    df['Calling Number'] = df['Calling Number'].astype(str)
    df['Called Number'] = df['Called Number'].astype(str)
    df['CALL_TYPE'] = df['CALL_TYPE'].astype(str).str.strip()
    sheet_owner_number = str(sheet_owner_number)

    # Modified relevant calls filtering
    relevant_calls = pd.concat([
        df[(df['Calling Number'] == sheet_owner_number) & df['CALL_TYPE'].str.contains('1', na=False)],
        df[(df['Called Number'] == sheet_owner_number) & df['CALL_TYPE'].str.contains('2', na=False)]
    ])

    if relevant_calls.empty:
        print("Warning: No relevant calls found for sheet owner")
        return []

    site_visits = relevant_calls['Site ID'].value_counts().reset_index()
    site_visits.columns = ['Site ID', 'Number_of_Visits']

    # Clean up Site IDs - convert from float to clean string
    site_visits['Site ID'] = site_visits['Site ID'].apply(lambda x: str(int(float(x))) if pd.notnull(x) else '')

    # Get all site information from database
    site_info = SiteInformation.objects.all()
    
    # Create different lookup dictionaries for each matching strategy
    ecgi_dict = {}
    for site in site_info:
        # Store both the original and stripped versions of lac_cell_id_ecgi
        ecgi_str = str(site.lac_cell_id_ecgi).strip()
        site_data = {
            'name': site.site_name,
            'lat': site.latitude,
            'long': site.longitude
        }
        ecgi_dict[ecgi_str] = site_data  # Original version
        if ecgi_str.startswith('0'):  # Store version without leading zero
            ecgi_dict[ecgi_str[1:]] = site_data
        
    # Create dictionaries for cell_id matches
    cell_id_dict_5 = {}
    cell_id_dict_4 = {}
    for site in site_info:
        cell_id = str(site.cell_id).strip()
        site_data = {
            'name': site.site_name,
            'lat': site.latitude,
            'long': site.longitude
        }
        if len(cell_id) >= 5:
            cell_id_dict_5[cell_id[-5:]] = site_data
        if len(cell_id) >= 4:
            cell_id_dict_4[cell_id[-4:]] = site_data

    print(f"\nPrepared lookup dictionaries:")
    print(f"- ECGI matches possible: {len(ecgi_dict)}")
    print(f"- 5-digit cell ID matches possible: {len(cell_id_dict_5)}")
    print(f"- 4-digit cell ID matches possible: {len(cell_id_dict_4)}")

    def find_site_info(site_id):
        site_id = str(site_id).strip()
        match_type = None
        
        # Debug print for specific site
        if site_id == "507119219":
            print(f"\nDEBUG - Processing site ID: {site_id}")
            print(f"Step 1: Checking if '{site_id}' exists in ecgi_dict")
            print(f"Step 2: Checking if '0{site_id}' exists in ecgi_dict")
            if f"0{site_id}" in ecgi_dict:
                print(f"Found match with '0{site_id}'!")
        
        # Step 1: Check full site ID match
        if site_id in ecgi_dict:
            print(f"Found full match for {site_id}")
            match_type = "full_match"
            return ecgi_dict[site_id], match_type
            
        # Step 2: Check with leading zero
        zero_padded = f"0{site_id}"
        if zero_padded in ecgi_dict:
            print(f"Found zero-padded match for {site_id} using {zero_padded}")
            match_type = "zero_padded_match"
            return ecgi_dict[zero_padded], match_type
            
        # Step 3: Check last 5 digits
        if len(site_id) >= 5:
            last_5 = site_id[-5:]
            if last_5 in cell_id_dict_5:
                print(f"Found 5-digit match for {site_id} using {last_5}")
                match_type = "5_digit_match"
                return cell_id_dict_5[last_5], match_type
                
        # Step 4: Check last 4 digits
        if len(site_id) >= 4:
            last_4 = site_id[-4:]
            if last_4 in cell_id_dict_4:
                print(f"Found 4-digit match for {site_id} using {last_4}")
                match_type = "4_digit_match"
                return cell_id_dict_4[last_4], match_type
        
        print(f"No match found for {site_id} in any step")
        return {'name': 'Unknown', 'lat': None, 'long': None}, "no_match"

    # Track matching statistics
    match_stats = {
        "full_match": 0,
        "zero_padded_match": 0,
        "5_digit_match": 0,
        "4_digit_match": 0,
        "no_match": 0
    }

    # Add location information to site_visits
    for index, row in site_visits.iterrows():
        site_id = row['Site ID']  # Already cleaned above
        site_data, match_type = find_site_info(site_id)
        match_stats[match_type] += 1
        
        site_visits.at[index, 'Site Name'] = site_data['name']
        site_visits.at[index, 'LAT'] = site_data['lat']
        site_visits.at[index, 'LON'] = site_data['long']

    # Print matching statistics
    print("\nMatching Statistics:")
    print(f"- Full matches: {match_stats['full_match']}")
    print(f"- Zero-padded matches: {match_stats['zero_padded_match']}")
    print(f"- 5-digit matches: {match_stats['5_digit_match']}")
    print(f"- 4-digit matches: {match_stats['4_digit_match']}")
    print(f"- Unmatched sites: {match_stats['no_match']}")

    result = site_visits[['Site ID', 'Site Name', 'LAT', 'LON', 'Number_of_Visits']].to_dict('records')
    print(f"\nReturning {len(result)} site records")
    
    return result