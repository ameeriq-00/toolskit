from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from rest_framework.response import Response
from django.db import transaction
from .models import SiteInformation
from .excel_analyzer import process_excel_files
import pandas as pd
import numpy as np

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_user_info(request):
    return Response({
        'username': request.user.username,
        'is_staff': request.user.is_staff
    })

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def analyze_excel(request):
    if 'file' not in request.FILES:
        return Response({"error": "No file uploaded"}, status=400)

    file = request.FILES['file']
    
    try:
        df = pd.read_excel(file)
        
        results = {
            "filtered_calls": filter_and_aggregate_calls(df),
            "aggregated_caller_numbers": aggregate_by_caller_number(df),
            "imei_usage": aggregate_imei_usage(df),
            "most_visited_sites": summarize_most_visited_sites(df)
        }
        
        return Response(results)
    except Exception as e:
        return Response({"error": str(e)}, status=400)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def analyze_excel_z(request):
    if 'main_file' not in request.FILES or 'imei_file' not in request.FILES:
        return Response({"error": "Both main file and IMEI file are required"}, status=400)

    main_file = request.FILES['main_file']
    imei_file = request.FILES['imei_file']
    
    try:
        results = process_excel_files(main_file, imei_file)
        
        def handle_nan(obj):
            if isinstance(obj, dict):
                return {k: handle_nan(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [handle_nan(v) for v in obj]
            elif isinstance(obj, float) and np.isnan(obj):
                return None
            return obj
        
        results = handle_nan(results)
        
        return Response(results)
    except Exception as e:
        return Response({"error": str(e)}, status=500)

@api_view(['POST'])
@permission_classes([IsAdminUser])
def upload_site_info(request):
    if 'site_info_file' not in request.FILES:
        return Response({"error": "Site information file is required"}, status=400)

    site_info_file = request.FILES['site_info_file']
    
    try:
        df = pd.read_excel(site_info_file)
        
        with transaction.atomic():
            SiteInformation.objects.all().delete()
            
            for _, row in df.iterrows():
                SiteInformation.objects.create(
                    governorate=row['Governorate'],
                    site_enb_id=row['Site/eNBId'],
                    cell_id=row['Cell ID'],
                    site_name=row['Site Name'],
                    latitude=row['lat'],
                    longitude=row['Long'],
                    bore=row['Bore'],
                    lac_cell_id_ecgi=row['LAC_Cell ID/ECGI']
                )
        
        return Response({"message": "Site information uploaded and saved successfully"})
    except Exception as e:
        return Response({"error": str(e)}, status=400)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def number_lookup(request):
    number = request.GET.get('number', '')
    info = f"Information for number: {number}"
    return Response({"number": number, "info": info})



# Helper functions for ExcelAnalyzer
def filter_and_aggregate_calls(df):
    def process_number(number):
        if isinstance(number, str):
            return number[3:] if number.startswith('964') else number
        return number

    df['CALLER_NUMBER'] = df['CALLER_NUMBER'].apply(process_number)
    df['CALLED_NUMBER'] = df['CALLED_NUMBER'].apply(process_number)

    filtered_df = df[(df['CALLER_NUMBER'].astype(str).str.startswith('7')) | 
                     (df['CALLED_NUMBER'].astype(str).str.startswith('7'))]

    aggregated = filtered_df.groupby('CALLER_NUMBER').size().reset_index(name='Number_of_Calls')
    return aggregated.sort_values('Number_of_Calls', ascending=False).to_dict('records')

def aggregate_by_caller_number(df):
    def is_valid_number(number):
        return isinstance(number, str) and not number.startswith('964') and not number.startswith('7')

    valid_numbers = df[df['CALLER_NUMBER'].apply(is_valid_number) | 
                       df['CALLED_NUMBER'].apply(is_valid_number)]

    aggregated = valid_numbers.groupby('CALLER_NUMBER').size().reset_index(name='Number_of_Calls')
    return aggregated.sort_values('Number_of_Calls', ascending=False).to_dict('records')





def aggregate_imei_usage(df):
    df['CALL_INITIAL_TIME'] = df['CALL_INITIAL_TIME'].apply(lambda x: pd.to_datetime(x.strip(), format='%d/%m/%Y %H:%M:%S', errors='coerce'))
    
    imei_usage = df.groupby('CHARGED_MOBILE_USER_IMEI').agg({
        'CALL_INITIAL_TIME': ['min', 'max']
    }).reset_index()
    
    imei_usage.columns = ['CHARGED_MOBILE_USER_IMEI', 'First_Use', 'Last_Use']
    imei_usage['Usage_Period'] = imei_usage.apply(
        lambda row: f"{row['First_Use'].strftime('%Y-%m-%d')} to {row['Last_Use'].strftime('%Y-%m-%d')}" if pd.notnull(row['First_Use']) and pd.notnull(row['Last_Use']) else "Unknown", 
        axis=1
    )
    
    return imei_usage[['CHARGED_MOBILE_USER_IMEI', 'Usage_Period']].to_dict('records')


def summarize_most_visited_sites(df):
    site_visits = df.groupby(['SITE_ID', 'SITE_NAME', 'LAT', 'LON']).size().reset_index(name='Number_of_Visits')
    return site_visits.sort_values('Number_of_Visits', ascending=False).to_dict('records')